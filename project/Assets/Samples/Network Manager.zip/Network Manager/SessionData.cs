using System;
using Unity.Netcode;
using UnityEngine;

[Serializable]
public class ServerSessionData : INetworkSerializable
{
    public string SessionName;
    public int MaxPlayers;
    public string MapName;
    public bool AllowSpectators;

    public void NetworkSerialize<T>(BufferSerializer<T> serializer) where T : IReaderWriter
    {
        serializer.SerializeValue(ref SessionName);
        serializer.SerializeValue(ref MaxPlayers);
        serializer.SerializeValue(ref MapName);
        serializer.SerializeValue(ref AllowSpectators);
    }
}

[Serializable]
public class ClientSessionData : INetworkSerializable
{
    public string PlayerId;
    public string DisplayName;
    public int SelectedCharacter;
    public int TeamId;

    public void NetworkSerialize<T>(BufferSerializer<T> serializer) where T : IReaderWriter
    {
        serializer.SerializeValue(ref PlayerId);
        serializer.SerializeValue(ref DisplayName);
        serializer.SerializeValue(ref SelectedCharacter);
        serializer.SerializeValue(ref TeamId);
    }
}